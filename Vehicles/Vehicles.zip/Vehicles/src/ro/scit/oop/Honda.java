package ro.scit.oop;

public class Honda extends Cars {

    private int tires;


    public int getTires() {
        return tires;
    }

    public void setTires(int tires) {
        this.tires = tires;
    }


}
