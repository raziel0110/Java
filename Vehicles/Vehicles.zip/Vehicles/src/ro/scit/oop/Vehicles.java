package ro.scit.oop;

public interface Vehicles {
    public abstract void start();

    public abstract void drive(double km);

    public abstract void stop() ;
}
