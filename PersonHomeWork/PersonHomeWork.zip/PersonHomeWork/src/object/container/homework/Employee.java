package object.container.homework;

public class Employee extends Person {
    public Employee(String name, int age, String adress) {
        super(name, age, adress);
    }


}
