package object.container.homework;

public class Unemployee extends Person {
    public Unemployee(String name, int age, String adress) {
        super(name, age, adress);
    }


}
